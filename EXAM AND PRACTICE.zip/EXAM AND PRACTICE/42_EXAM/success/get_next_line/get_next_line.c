#include <unistd.h>
#include<stdlib.h>

#include"get_next_line.h"

char *ft_strchr(char *s, int c)
{
    while (*s)
    {
        if (*s == (char)c)
            return (s);
        s++;    
    }
    return NULL;
}

int ft_strlen(char *s)
{
    int i=0;

    while (s[i])
        i++;
    return i;
}

void ft_strcpy(char *dst, char *src)
{
    while (*src)
        *dst++ = *src++;
    *dst = '\0';
}

char *ft_strdup(char *s)
{
    char * new = malloc (ft_strlen(s) + 1);
    if (!new)
        return NULL;
    ft_strcpy(new, s);
    return new;
}

char *ft_strjoin(char *str, char *str2)
{
    if(!str || !str2)
        return NULL;
    char *new = malloc(ft_strlen(str) + ft_strlen(str2) + 1);
    ft_strcpy(new, str);
    ft_strcpy(new + ft_strlen(str), str2);
    free(str);
    return new;
}

char *get_next_line(int fd)
{
    static  char buff[BUFFER_SIZE + 1];
    char    *line;
    char    *new_line;
    int     countread;

    if (BUFFER_SIZE < 1 || fd < 0)
        return NULL;

    line = ft_strdup(buff);

    while (!(new_line = ft_strchr(line, '\n')) && (countread = read(fd, buff, BUFFER_SIZE)))
    {
        buff[countread] = '\0';
        line = ft_strjoin(line, buff);
    }

    if (ft_strlen(line) == 0)
        return (free(line),NULL);

    if (new_line)
    {
        ft_strcpy(buff,new_line+1);
        *(new_line+1) = '\0';
    }

    else
        buff[0] = '\0';
        
    return line;
}
